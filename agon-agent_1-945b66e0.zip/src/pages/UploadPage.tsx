import React, { useState, useCallback } from 'react';
import { motion } from 'framer-motion';
import { Upload, FileVideo, CheckCircle2, Loader2, Scissors, Sparkles, Mic } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

const UploadPage = () => {
  const [isDragging, setIsDragging] = useState(false);
  const [file, setFile] = useState<File | null>(null);
  const [isUploading, setIsUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const navigate = useNavigate();

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  }, []);

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  }, []);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const files = e.dataTransfer.files;
    if (files && files[0]) {
      setFile(files[0]);
    }
  }, []);

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setFile(e.target.files[0]);
    }
  };

  const startUpload = () => {
    if (!file) return;
    setIsUploading(true);
    
    // Simulate upload progress
    let progress = 0;
    const interval = setInterval(() => {
      progress += Math.random() * 30;
      if (progress >= 100) {
        setUploadProgress(100);
        clearInterval(interval);
        setTimeout(() => {
          navigate('/editor');
        }, 1000);
      } else {
        setUploadProgress(progress);
      }
    }, 500);
  };

  return (
    <div className="pt-24 px-4 min-h-screen flex items-center justify-center">
      <div className="max-w-3xl w-full">
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="glass border border-white/10 rounded-3xl p-12 text-center"
        >
          {!file && !isUploading ? (
            <div
              onDragOver={handleDragOver}
              onDragLeave={handleDragLeave}
              onDrop={handleDrop}
              className={`border-2 border-dashed rounded-2xl p-16 transition-all cursor-pointer ${
                isDragging ? 'border-purple-500 bg-purple-500/10' : 'border-white/10 hover:border-white/20'
              }`}
              onClick={() => document.getElementById('fileInput')?.click()}
            >
              <input
                type="file"
                id="fileInput"
                className="hidden"
                accept="video/*"
                onChange={handleFileSelect}
              />
              <div className="w-20 h-20 bg-purple-600/20 rounded-full flex items-center justify-center mx-auto mb-6">
                <Upload className="w-10 h-10 text-purple-500" />
              </div>
              <h2 className="text-2xl font-bold mb-2">Upload your raw footage</h2>
              <p className="text-gray-400 mb-8">Drag and drop your video file here or click to browse</p>
              <div className="flex items-center justify-center gap-6 text-sm text-gray-500">
                <div className="flex items-center gap-1"><CheckCircle2 className="w-4 h-4" /> MP4, MOV, AVI</div>
                <div className="flex items-center gap-1"><CheckCircle2 className="w-4 h-4" /> Up to 2GB</div>
                <div className="flex items-center gap-1"><CheckCircle2 className="w-4 h-4" /> 4K Supported</div>
              </div>
            </div>
          ) : (
            <div className="space-y-8">
              <div className="flex items-center justify-center">
                <div className="relative">
                  <div className="w-24 h-24 bg-purple-600/20 rounded-2xl flex items-center justify-center">
                    <FileVideo className="w-12 h-12 text-purple-500" />
                  </div>
                  {isUploading && (
                    <motion.div
                      className="absolute -bottom-2 -right-2 bg-green-500 rounded-full p-1"
                      initial={{ scale: 0 }}
                      animate={{ scale: 1 }}
                    >
                      <CheckCircle2 className="w-5 h-5 text-white" />
                    </motion.div>
                  )}
                </div>
              </div>

              <div>
                <h3 className="text-xl font-bold truncate max-w-md mx-auto">{file?.name}</h3>
                <p className="text-gray-400">{(file?.size! / (1024 * 1024)).toFixed(2)} MB</p>
              </div>

              {isUploading ? (
                <div className="space-y-4">
                  <div className="w-full bg-white/5 rounded-full h-2 overflow-hidden">
                    <motion.div
                      className="h-full bg-purple-600"
                      initial={{ width: 0 }}
                      animate={{ width: `${uploadProgress}%` }}
                    />
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-400">Uploading to AI Engine...</span>
                    <span className="font-bold">{Math.round(uploadProgress)}%</span>
                  </div>
                </div>
              ) : (
                <div className="flex flex-col gap-4">
                  <button
                    onClick={startUpload}
                    className="w-full py-4 bg-purple-600 hover:bg-purple-700 text-white font-bold rounded-xl transition-all glow-button"
                  >
                    Process with AI
                  </button>
                  <button
                    onClick={() => setFile(null)}
                    className="w-full py-4 glass border border-white/10 text-white font-bold rounded-xl hover:bg-white/5 transition-all"
                  >
                    Cancel
                  </button>
                </div>
              )}

              <div className="grid grid-cols-3 gap-4 pt-8 border-t border-white/5">
                <div className="flex flex-col items-center gap-2 opacity-50">
                  <Scissors className="w-5 h-5" />
                  <span className="text-xs uppercase tracking-widest">Auto-Cut</span>
                </div>
                <div className="flex flex-col items-center gap-2 opacity-50">
                  <Sparkles className="w-5 h-5" />
                  <span className="text-xs uppercase tracking-widest">Enhance</span>
                </div>
                <div className="flex flex-col items-center gap-2 opacity-50">
                  <Mic className="w-5 h-5" />
                  <span className="text-xs uppercase tracking-widest">Noise Fix</span>
                </div>
              </div>
            </div>
          )}
        </motion.div>
      </div>
    </div>
  );
};

export default UploadPage;
