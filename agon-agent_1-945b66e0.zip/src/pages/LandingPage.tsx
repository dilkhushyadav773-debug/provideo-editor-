import React from 'react';
import { motion } from 'framer-motion';
import { Play, Scissors, Sparkles, Zap, Layers, Share2, TrendingUp, Mic, Languages } from 'lucide-react';
import { Link } from 'react-router-dom';

const LandingPage = () => {
  return (
    <div className="pt-16">
      {/* Hero Section */}
      <section className="relative min-h-[90vh] flex items-center justify-center overflow-hidden px-4">
        <div className="absolute inset-0 z-0">
          <video 
            autoPlay 
            muted 
            loop 
            className="w-full h-full object-cover opacity-30"
            src="/videos/abstract-bg.mp4"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-bg-dark via-transparent to-bg-dark" />
        </div>

        <div className="relative z-10 max-w-5xl mx-auto text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <span className="inline-block px-4 py-1.5 mb-6 text-sm font-medium tracking-wider text-purple-400 uppercase bg-purple-500/10 border border-purple-500/20 rounded-full">
              The Future of Video Editing is Here
            </span>
            <h1 className="text-5xl md:text-8xl font-black tracking-tighter mb-6 leading-tight">
              RAW TO <span className="text-gradient">PRO</span> <br />
              IN SECONDS.
            </h1>
            <p className="text-xl text-gray-400 mb-10 max-w-2xl mx-auto leading-relaxed">
              ProCut AI automatically edits your raw footage into viral-ready videos. 
              Auto-cuts, subtitles, transitions, and magic effects—all powered by AI.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <Link
                to="/upload"
                className="px-8 py-4 bg-white text-black font-bold rounded-xl flex items-center gap-2 hover:bg-gray-200 transition-all glow-button"
              >
                <Play className="w-5 h-5 fill-current" />
                Start Editing Free
              </Link>
              <Link
                to="/pricing"
                className="px-8 py-4 glass text-white font-bold rounded-xl border border-white/10 hover:bg-white/5 transition-all"
              >
                View Pricing
              </Link>
            </div>
          </motion.div>
        </div>

        {/* Floating elements for visual flair */}
        <div className="absolute bottom-10 left-1/2 -translate-x-1/2 flex items-center gap-8 opacity-40 animate-pulse">
           <div className="flex items-center gap-2"><Scissors className="w-4 h-4" /> <span>Auto-Cut</span></div>
           <div className="flex items-center gap-2"><Sparkles className="w-4 h-4" /> <span>AI Effects</span></div>
           <div className="flex items-center gap-2"><Mic className="w-4 h-4" /> <span>Voice Fix</span></div>
        </div>
      </section>

      {/* Features Grid */}
      <section id="features" className="py-24 px-4 max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-5xl font-bold mb-4">Unleash Your Creativity</h2>
          <p className="text-gray-400">Everything you need to create world-class content.</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {features.map((feature, idx) => (
            <motion.div
              key={idx}
              whileHover={{ y: -10 }}
              className="p-8 rounded-2xl glass border border-white/5 hover:border-purple-500/30 transition-all"
            >
              <div className={`w-12 h-12 rounded-lg bg-gradient-to-br ${feature.color} flex items-center justify-center mb-6`}>
                <feature.icon className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-xl font-bold mb-3">{feature.title}</h3>
              <p className="text-gray-400 leading-relaxed">{feature.desc}</p>
            </motion.div>
          ))}
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-24 px-4">
        <div className="max-w-4xl mx-auto glass rounded-3xl p-12 text-center border border-purple-500/20 relative overflow-hidden">
          <div className="absolute top-0 right-0 w-64 h-64 bg-purple-600/20 blur-[100px] -z-10" />
          <h2 className="text-4xl font-bold mb-6">Ready to go viral?</h2>
          <p className="text-xl text-gray-400 mb-10">Join 50,000+ creators using ProCut AI to dominate YouTube, TikTok, and Reels.</p>
          <Link
            to="/upload"
            className="inline-block px-10 py-5 bg-gradient-to-r from-purple-600 to-fuchsia-600 text-white font-bold rounded-2xl hover:opacity-90 transition-all glow-button"
          >
            Get Started Now
          </Link>
        </div>
      </section>
    </div>
  );
};

const features = [
  {
    title: 'AI Auto-Cut',
    desc: 'Automatically removes silence, fillers (um, ah), and mistakes from your raw footage.',
    icon: Scissors,
    color: 'from-blue-500 to-cyan-500'
  },
  {
    title: 'Magic Subtitles',
    desc: 'Generate stunning, animated captions that keep viewers engaged throughout.',
    icon: Languages,
    color: 'from-purple-500 to-pink-500'
  },
  {
    title: 'One-Click Viral',
    desc: 'Convert long-form videos into high-engagement Shorts and Reels instantly.',
    icon: TrendingUp,
    color: 'from-orange-500 to-red-500'
  },
  {
    title: 'AI Voice Fix',
    desc: 'Remove background noise and enhance your voice to studio quality automatically.',
    icon: Mic,
    color: 'from-green-500 to-emerald-500'
  },
  {
    title: 'Smart Transitions',
    desc: 'AI analyzes your scenes and adds the perfect transitions and zoom effects.',
    icon: Layers,
    color: 'from-indigo-500 to-purple-500'
  },
  {
    title: 'Multi-Platform Export',
    desc: 'Optimized exports for YouTube, TikTok, Instagram, and LinkedIn in one click.',
    icon: Share2,
    color: 'from-pink-500 to-rose-500'
  }
];

export default LandingPage;
