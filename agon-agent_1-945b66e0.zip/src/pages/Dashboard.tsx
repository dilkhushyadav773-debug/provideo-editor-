import React from 'react';
import { motion } from 'framer-motion';
import { Plus, Video, Clock, MoreVertical, Play } from 'lucide-react';
import { Link } from 'react-router-dom';

const Dashboard = () => {
  const projects = [
    { id: 1, title: 'My Awesome Vlog #24', date: '2 hours ago', duration: '12:45', thumbnail: 'https://images.unsplash.com/photo-1492691523567-6170c3295db6?auto=format&fit=crop&q=80&w=400' },
    { id: 2, title: 'Product Review - Tech', date: 'Yesterday', duration: '05:20', thumbnail: 'https://images.unsplash.com/photo-1550745165-9bc0b252726f?auto=format&fit=crop&q=80&w=400' },
    { id: 3, title: 'TikTok Dance Trend', date: '3 days ago', duration: '00:15', thumbnail: 'https://images.unsplash.com/photo-1541535881962-e6686230e0c1?auto=format&fit=crop&q=80&w=400' },
  ];

  return (
    <div className="pt-24 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
      <div className="flex items-center justify-between mb-12">
        <div>
          <h1 className="text-3xl font-bold">Your Projects</h1>
          <p className="text-gray-400">Welcome back, Creator.</p>
        </div>
        <Link
          to="/upload"
          className="flex items-center gap-2 bg-purple-600 hover:bg-purple-700 px-6 py-3 rounded-xl font-bold transition-all glow-button"
        >
          <Plus className="w-5 h-5" />
          New Project
        </Link>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {/* Create Card */}
        <Link
          to="/upload"
          className="group relative aspect-video rounded-2xl border-2 border-dashed border-white/10 flex flex-col items-center justify-center gap-3 hover:border-purple-500/50 hover:bg-white/5 transition-all"
        >
          <div className="w-12 h-12 rounded-full bg-white/5 flex items-center justify-center group-hover:scale-110 transition-transform">
            <Plus className="w-6 h-6 text-gray-400" />
          </div>
          <span className="text-gray-400 font-medium">Create New</span>
        </Link>

        {/* Project Cards */}
        {projects.map((project) => (
          <motion.div
            key={project.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="group glass rounded-2xl overflow-hidden border border-white/5 hover:border-white/10 transition-all"
          >
            <div className="relative aspect-video overflow-hidden">
              <img 
                src={project.thumbnail} 
                alt={project.title}
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
              />
              <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                <Link to="/editor" className="p-3 bg-white text-black rounded-full hover:scale-110 transition-transform">
                  <Play className="w-6 h-6 fill-current" />
                </Link>
              </div>
              <div className="absolute bottom-2 right-2 px-2 py-1 bg-black/70 backdrop-blur-md rounded text-xs font-medium">
                {project.duration}
              </div>
            </div>
            <div className="p-4">
              <div className="flex items-start justify-between">
                <div>
                  <h3 className="font-bold truncate max-w-[180px]">{project.title}</h3>
                  <div className="flex items-center gap-2 mt-1 text-xs text-gray-400">
                    <Clock className="w-3 h-3" />
                    {project.date}
                  </div>
                </div>
                <button className="p-1 hover:bg-white/10 rounded-lg transition-colors">
                  <MoreVertical className="w-5 h-5 text-gray-400" />
                </button>
              </div>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
};

export default Dashboard;
