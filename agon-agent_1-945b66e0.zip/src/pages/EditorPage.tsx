import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Scissors, Sparkles, Languages, Music, Wand2, 
  Play, Pause, SkipBack, SkipForward, Maximize2, 
  Layers, Settings, Download, Save, ChevronLeft,
  Volume2, Eye, Layout, Type, Palette, Loader2
} from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';

const EditorPage = () => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [activeTab, setActiveTab] = useState('magic');
  const [isProcessing, setIsProcessing] = useState(false);
  const navigate = useNavigate();

  const handleMagicEdit = () => {
    setIsProcessing(true);
    setTimeout(() => {
      setIsProcessing(false);
      // In a real app, this would update the video preview
    }, 3000);
  };

  return (
    <div className="h-screen flex flex-col bg-[#0a0a0a] overflow-hidden">
      {/* Editor Header */}
      <header className="h-14 border-b border-white/5 flex items-center justify-between px-4 glass">
        <div className="flex items-center gap-4">
          <Link to="/dashboard" className="p-2 hover:bg-white/5 rounded-lg transition-colors">
            <ChevronLeft className="w-5 h-5" />
          </Link>
          <div className="h-6 w-[1px] bg-white/10 mx-2" />
          <h1 className="text-sm font-bold tracking-wide">MY_AWESOME_VLOG_01.MP4</h1>
          <span className="px-2 py-0.5 rounded bg-purple-500/20 text-purple-400 text-[10px] font-black uppercase">4K</span>
        </div>
        
        <div className="flex items-center gap-3">
          <button className="flex items-center gap-2 px-3 py-1.5 rounded-lg hover:bg-white/5 text-sm font-medium transition-colors">
            <Save className="w-4 h-4" />
            Save
          </button>
          <button 
            onClick={() => navigate('/export')}
            className="flex items-center gap-2 px-4 py-1.5 bg-purple-600 hover:bg-purple-700 text-white rounded-lg text-sm font-bold transition-all glow-button"
          >
            <Download className="w-4 h-4" />
            Export
          </button>
        </div>
      </header>

      <div className="flex-1 flex overflow-hidden">
        {/* Sidebar Tools */}
        <aside className="w-16 border-r border-white/5 flex flex-col items-center py-6 gap-6 glass">
          <ToolIcon icon={Wand2} active={activeTab === 'magic'} onClick={() => setActiveTab('magic')} label="AI Magic" />
          <ToolIcon icon={Scissors} active={activeTab === 'edit'} onClick={() => setActiveTab('edit')} label="Edit" />
          <ToolIcon icon={Type} active={activeTab === 'text'} onClick={() => setActiveTab('text')} label="Subtitles" />
          <ToolIcon icon={Music} active={activeTab === 'audio'} onClick={() => setActiveTab('audio')} label="Audio" />
          <ToolIcon icon={Palette} active={activeTab === 'color'} onClick={() => setActiveTab('color')} label="Color" />
          <div className="mt-auto">
            <ToolIcon icon={Settings} active={false} onClick={() => {}} label="Settings" />
          </div>
        </aside>

        {/* Main Content */}
        <main className="flex-1 flex flex-col relative">
          {/* Preview Area */}
          <div className="flex-1 bg-black flex items-center justify-center p-8 relative">
            <div className="relative aspect-video w-full max-w-4xl bg-zinc-900 rounded-xl overflow-hidden shadow-2xl group">
              {/* Mock Video Content */}
              <div className="absolute inset-0 flex items-center justify-center">
                <VideoPlaceholder isPlaying={isPlaying} />
              </div>
              
              {/* Video Overlays */}
              <div className="absolute inset-x-0 bottom-0 p-6 bg-gradient-to-t from-black/80 to-transparent opacity-0 group-hover:opacity-100 transition-opacity">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    <button onClick={() => setIsPlaying(!isPlaying)} className="hover:scale-110 transition-transform">
                      {isPlaying ? <Pause className="w-6 h-6 fill-current" /> : <Play className="w-6 h-6 fill-current" />}
                    </button>
                    <div className="text-sm font-mono">00:42 / 05:12</div>
                  </div>
                  <div className="flex items-center gap-4">
                    <Volume2 className="w-5 h-5" />
                    <Maximize2 className="w-5 h-5" />
                  </div>
                </div>
              </div>

              {/* AI Processing Overlay */}
              <AnimatePresence>
                {isProcessing && (
                  <motion.div 
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    className="absolute inset-0 glass-dark flex flex-col items-center justify-center z-20"
                  >
                    <Loader2 className="w-12 h-12 text-purple-500 animate-spin mb-4" />
                    <h3 className="text-xl font-bold">AI is working its magic...</h3>
                    <p className="text-gray-400 mt-2">Auto-cutting silence and adding subtitles</p>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </div>

          {/* Timeline */}
          <div className="h-64 border-t border-white/5 glass flex flex-col">
            <div className="h-10 border-b border-white/5 flex items-center px-4 justify-between">
              <div className="flex gap-4">
                <button className="text-xs font-bold text-gray-400 hover:text-white uppercase tracking-widest">Main Track</button>
                <button className="text-xs font-bold text-gray-400 hover:text-white uppercase tracking-widest">Audio</button>
                <button className="text-xs font-bold text-gray-400 hover:text-white uppercase tracking-widest">Effects</button>
              </div>
              <div className="flex items-center gap-2">
                <button className="p-1 hover:bg-white/5 rounded"><SkipBack className="w-4 h-4" /></button>
                <button className="p-1 hover:bg-white/5 rounded"><SkipForward className="w-4 h-4" /></button>
              </div>
            </div>
            
            <div className="flex-1 overflow-x-auto p-4 relative">
              {/* Timeline Grid */}
              <div className="absolute inset-0 pointer-events-none opacity-5">
                <div className="h-full w-full" style={{ backgroundImage: 'linear-gradient(90deg, white 1px, transparent 1px)', backgroundSize: '40px 100%' }} />
              </div>
              
              {/* Timeline Tracks */}
              <div className="space-y-2">
                {/* Visual Track */}
                <div className="h-16 bg-purple-600/10 border border-purple-500/20 rounded-lg relative overflow-hidden flex items-center px-2">
                  <div className="absolute inset-0 flex">
                    {[1,2,3,4,5,6].map(i => (
                      <div key={i} className="h-full w-32 border-r border-white/5 flex-shrink-0">
                        <img src={`https://picsum.photos/seed/${i+10}/200/100`} className="w-full h-full object-cover opacity-30" alt="" />
                      </div>
                    ))}
                  </div>
                  <span className="relative text-[10px] font-bold bg-black/50 px-2 py-1 rounded">CLIP_001.MP4</span>
                </div>
                
                {/* Subtitle Track */}
                <div className="h-8 bg-blue-600/10 border border-blue-500/20 rounded-lg flex items-center px-4">
                  <span className="text-[10px] font-bold text-blue-400">AI SUBTITLES (AUTO-GENERATED)</span>
                </div>

                {/* Audio Track */}
                <div className="h-12 bg-green-600/10 border border-green-500/20 rounded-lg flex items-center relative overflow-hidden">
                  <div className="absolute inset-0 flex items-center px-2">
                    <div className="w-full h-8 flex items-center gap-[2px]">
                      {Array.from({length: 100}).map((_, i) => (
                        <div key={i} className="w-[2px] bg-green-500/40" style={{ height: `${Math.random() * 100}%` }} />
                      ))}
                    </div>
                  </div>
                </div>
              </div>

              {/* Playhead */}
              <div className="absolute top-0 left-1/4 bottom-0 w-[2px] bg-purple-500 z-10">
                <div className="absolute -top-1 -left-[5px] w-3 h-3 bg-purple-500 rotate-45" />
              </div>
            </div>
          </div>
        </main>

        {/* Right Properties Panel */}
        <aside className="w-72 border-l border-white/5 glass p-6 overflow-y-auto">
          <AnimatePresence mode="wait">
            {activeTab === 'magic' && (
              <motion.div
                key="magic"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="space-y-8"
              >
                <div>
                  <h3 className="text-lg font-bold mb-4 flex items-center gap-2">
                    <Sparkles className="w-5 h-5 text-purple-400" />
                    AI Quick Actions
                  </h3>
                  <div className="space-y-3">
                    <MagicAction 
                      title="Auto-Cut Silence" 
                      desc="Removes all silent gaps instantly"
                      onClick={handleMagicEdit}
                    />
                    <MagicAction 
                      title="Viral Shorts" 
                      desc="Format for TikTok/Reels"
                      onClick={handleMagicEdit}
                    />
                    <MagicAction 
                      title="Voice Enhance" 
                      desc="Remove background noise"
                      onClick={handleMagicEdit}
                    />
                    <MagicAction 
                      title="Auto-Captions" 
                      desc="Add animated subtitles"
                      onClick={handleMagicEdit}
                    />
                  </div>
                </div>

                <div className="pt-6 border-t border-white/5">
                  <h4 className="text-sm font-bold text-gray-400 mb-4 uppercase tracking-widest">Style Presets</h4>
                  <div className="grid grid-cols-2 gap-3">
                    {['Cinematic', 'Vlog', 'Modern', 'Retro'].map(style => (
                      <button key={style} className="p-3 rounded-xl border border-white/5 hover:border-purple-500/50 bg-white/5 text-xs font-medium transition-all">
                        {style}
                      </button>
                    ))}
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </aside>
      </div>
    </div>
  );
};

const ToolIcon = ({ icon: Icon, active, onClick, label }: any) => (
  <button 
    onClick={onClick}
    className={`group relative p-3 rounded-xl transition-all ${
      active ? 'bg-purple-600 text-white shadow-[0_0_15px_rgba(139,92,246,0.5)]' : 'text-gray-400 hover:text-white hover:bg-white/5'
    }`}
  >
    <Icon className="w-6 h-6" />
    <span className="absolute left-full ml-4 px-2 py-1 bg-white text-black text-[10px] font-black rounded opacity-0 group-hover:opacity-100 pointer-events-none transition-opacity whitespace-nowrap z-50 uppercase tracking-tighter">
      {label}
    </span>
  </button>
);

const MagicAction = ({ title, desc, onClick }: any) => (
  <button 
    onClick={onClick}
    className="w-full p-4 rounded-2xl border border-white/5 bg-white/5 hover:bg-white/10 hover:border-purple-500/30 text-left transition-all group"
  >
    <div className="font-bold text-sm group-hover:text-purple-400 transition-colors">{title}</div>
    <div className="text-xs text-gray-400 mt-1">{desc}</div>
  </button>
);

const VideoPlaceholder = ({ isPlaying }: { isPlaying: boolean }) => (
  <div className="relative w-full h-full flex flex-col items-center justify-center">
    <img 
      src="https://images.unsplash.com/photo-1492691523567-6170c3295db6?auto=format&fit=crop&q=80&w=1200" 
      className={`absolute inset-0 w-full h-full object-cover opacity-60 transition-transform duration-1000 ${isPlaying ? 'scale-110' : 'scale-100'}`}
      alt="Preview"
    />
    <div className="z-10 text-center">
      <div className="text-4xl font-black italic text-white/20 mb-2">PROCUT PREVIEW</div>
      {isPlaying && (
        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="text-purple-400 font-mono text-sm"
        >
          ● RECORDING_LIVE_FEED
        </motion.div>
      )}
    </div>
  </div>
);

export default EditorPage;
