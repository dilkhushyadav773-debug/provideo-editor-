import React from 'react';
import { Check, Zap, Star, Crown } from 'lucide-react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';

const PricingPage = () => {
  const plans = [
    {
      name: 'Free',
      price: '$0',
      desc: 'Perfect for hobbyists',
      features: ['720p Export', '3 AI Edits / month', 'Watermark included', 'Basic transitions'],
      icon: Zap,
      color: 'from-blue-500 to-cyan-500',
      button: 'Start for Free',
      popular: false
    },
    {
      name: 'Creator',
      price: '$19',
      desc: 'For serious content creators',
      features: ['4K Ultra HD Export', 'Unlimited AI Edits', 'No Watermark', 'AI Subtitles', 'Auto-Cut Silence', 'Priority Support'],
      icon: Star,
      color: 'from-purple-500 to-fuchsia-500',
      button: 'Get Started',
      popular: true
    },
    {
      name: 'Studio',
      price: '$49',
      desc: 'For professional teams',
      features: ['Everything in Creator', 'Team Collaboration', 'Custom AI Models', 'API Access', 'Dedicated Manager', 'Custom Branding'],
      icon: Crown,
      color: 'from-orange-500 to-red-500',
      button: 'Contact Sales',
      popular: false
    }
  ];

  return (
    <div className="pt-32 pb-24 px-4 max-w-7xl mx-auto">
      <div className="text-center mb-16">
        <h1 className="text-4xl md:text-6xl font-black mb-4">Simple, Transparent <span className="text-gradient">Pricing</span></h1>
        <p className="text-gray-400 text-xl max-w-2xl mx-auto">Choose the plan that fits your creative journey. Upgrade or downgrade anytime.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        {plans.map((plan, idx) => (
          <motion.div
            key={idx}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: idx * 0.1 }}
            className={`relative p-8 rounded-3xl glass border border-white/5 flex flex-col ${plan.popular ? 'border-purple-500/50 ring-2 ring-purple-500/20' : ''}`}
          >
            {plan.popular && (
              <div className="absolute -top-4 left-1/2 -translate-x-1/2 bg-purple-600 text-white text-xs font-black px-4 py-1 rounded-full uppercase tracking-widest">
                Most Popular
              </div>
            )}
            
            <div className={`w-12 h-12 rounded-2xl bg-gradient-to-br ${plan.color} flex items-center justify-center mb-6`}>
              <plan.icon className="w-6 h-6 text-white" />
            </div>

            <h3 className="text-2xl font-bold mb-2">{plan.name}</h3>
            <div className="flex items-baseline gap-1 mb-4">
              <span className="text-4xl font-black">{plan.price}</span>
              <span className="text-gray-400">/month</span>
            </div>
            <p className="text-gray-400 mb-8 text-sm">{plan.desc}</p>

            <div className="space-y-4 mb-10 flex-1">
              {plan.features.map((feature, fIdx) => (
                <div key={fIdx} className="flex items-center gap-3 text-sm">
                  <div className="w-5 h-5 rounded-full bg-white/5 flex items-center justify-center flex-shrink-0">
                    <Check className="w-3 h-3 text-purple-400" />
                  </div>
                  <span className="text-gray-300">{feature}</span>
                </div>
              ))}
            </div>

            <Link
              to="/upload"
              className={`w-full py-4 rounded-xl font-bold text-center transition-all ${
                plan.popular 
                ? 'bg-purple-600 hover:bg-purple-700 text-white glow-button' 
                : 'glass border border-white/10 hover:bg-white/5 text-white'
              }`}
            >
              {plan.button}
            </Link>
          </motion.div>
        ))}
      </div>

      <div className="mt-20 glass rounded-3xl p-12 text-center border border-white/5 max-w-4xl mx-auto">
        <h2 className="text-2xl font-bold mb-4">Frequently Asked Questions</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 text-left mt-10">
          <div>
            <h4 className="font-bold mb-2">Can I cancel anytime?</h4>
            <p className="text-sm text-gray-400">Yes, you can cancel your subscription at any time from your dashboard settings. You'll keep access until the end of your billing period.</p>
          </div>
          <div>
            <h4 className="font-bold mb-2">What is AI Auto-Cut?</h4>
            <p className="text-sm text-gray-400">Our AI analyzes your video and automatically removes silence, filler words (um, ah), and mistakes, leaving only the best parts.</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PricingPage;
