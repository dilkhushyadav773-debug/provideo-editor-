import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Download, Share2, Youtube, Instagram, Twitter, CheckCircle2, Loader2, Play, ArrowLeft } from 'lucide-react';
import { Link } from 'react-router-dom';

const ExportPage = () => {
  const [status, setStatus] = useState<'rendering' | 'finished'>('rendering');
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    if (status === 'rendering') {
      const interval = setInterval(() => {
        setProgress(prev => {
          if (prev >= 100) {
            clearInterval(interval);
            setStatus('finished');
            return 100;
          }
          return prev + Math.random() * 5;
        });
      }, 300);
      return () => clearInterval(interval);
    }
  }, [status]);

  return (
    <div className="pt-24 pb-12 px-4 max-w-5xl mx-auto min-h-screen">
      <Link to="/editor" className="inline-flex items-center gap-2 text-gray-400 hover:text-white mb-8 transition-colors">
        <ArrowLeft className="w-4 h-4" />
        Back to Editor
      </Link>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
        {/* Preview Side */}
        <div className="space-y-6">
          <div className="relative aspect-video bg-zinc-900 rounded-3xl overflow-hidden border border-white/5 shadow-2xl">
            <img 
              src="https://images.unsplash.com/photo-1492691523567-6170c3295db6?auto=format&fit=crop&q=80&w=1200" 
              className={`w-full h-full object-cover ${status === 'rendering' ? 'opacity-40 blur-sm' : 'opacity-100'}`}
              alt="Final Preview"
            />
            {status === 'rendering' && (
              <div className="absolute inset-0 flex flex-col items-center justify-center">
                <Loader2 className="w-12 h-12 text-purple-500 animate-spin mb-4" />
                <div className="text-xl font-bold">Rendering... {Math.round(progress)}%</div>
                <p className="text-gray-400 mt-2 text-sm">Applying AI enhancements and transitions</p>
              </div>
            )}
            {status === 'finished' && (
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="w-16 h-16 bg-white text-black rounded-full flex items-center justify-center cursor-pointer hover:scale-110 transition-transform">
                  <Play className="w-8 h-8 fill-current ml-1" />
                </div>
              </div>
            )}
          </div>

          <div className="glass p-6 rounded-2xl border border-white/5">
            <h3 className="font-bold mb-4">Export Settings</h3>
            <div className="space-y-3">
              <div className="flex justify-between text-sm">
                <span className="text-gray-400">Resolution</span>
                <span className="font-bold">4K Ultra HD (3840 x 2160)</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-gray-400">Frame Rate</span>
                <span className="font-bold">60 FPS</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-gray-400">Format</span>
                <span className="font-bold">MP4 (H.264)</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-gray-400">Estimated Size</span>
                <span className="font-bold">428.5 MB</span>
              </div>
            </div>
          </div>
        </div>

        {/* Actions Side */}
        <div className="space-y-8">
          <div className="glass p-8 rounded-3xl border border-white/5 relative overflow-hidden">
            {status === 'finished' && (
              <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                className="absolute top-4 right-4 text-green-500 flex items-center gap-1 text-xs font-bold uppercase tracking-widest"
              >
                <CheckCircle2 className="w-4 h-4" /> Ready
              </motion.div>
            )}

            <h2 className="text-3xl font-black mb-6">Your video is ready!</h2>
            
            <div className="space-y-4">
              <button 
                disabled={status === 'rendering'}
                className={`w-full py-4 rounded-xl font-bold flex items-center justify-center gap-3 transition-all ${
                  status === 'rendering' 
                  ? 'bg-white/5 text-gray-500 cursor-not-allowed' 
                  : 'bg-white text-black hover:bg-gray-200 glow-button'
                }`}
              >
                <Download className="w-5 h-5" />
                Download Video
              </button>
              
              <button 
                disabled={status === 'rendering'}
                className="w-full py-4 glass border border-white/10 text-white font-bold rounded-xl hover:bg-white/5 transition-all flex items-center justify-center gap-3"
              >
                <Share2 className="w-5 h-5" />
                Copy Share Link
              </button>
            </div>

            <div className="mt-12">
              <h4 className="text-sm font-bold text-gray-400 mb-6 uppercase tracking-widest">Post Directly to</h4>
              <div className="grid grid-cols-3 gap-4">
                <SocialButton icon={Youtube} label="YouTube" disabled={status === 'rendering'} />
                <SocialButton icon={Instagram} label="Reels" disabled={status === 'rendering'} />
                <SocialButton icon={Twitter} label="Twitter" disabled={status === 'rendering'} />
              </div>
            </div>
          </div>

          <div className="bg-purple-600/10 border border-purple-500/20 p-6 rounded-2xl">
            <h4 className="font-bold mb-2 flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-purple-400" />
              AI Summary
            </h4>
            <p className="text-sm text-gray-400 leading-relaxed">
              We've automatically removed 12 minutes of silence, added 42 transitions, and generated subtitles in English. Your video is now optimized for maximum engagement.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

const SocialButton = ({ icon: Icon, label, disabled }: any) => (
  <button 
    disabled={disabled}
    className={`flex flex-col items-center gap-2 p-4 rounded-2xl glass border border-white/5 transition-all ${
      disabled ? 'opacity-50 cursor-not-allowed' : 'hover:border-purple-500/30 hover:bg-white/5'
    }`}
  >
    <Icon className="w-6 h-6" />
    <span className="text-[10px] font-bold uppercase tracking-tighter">{label}</span>
  </button>
);

export default ExportPage;
